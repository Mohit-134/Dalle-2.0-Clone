import Home from "./Home";
import Createpost from "./Createpost";


export{
    Home,
    Createpost
}