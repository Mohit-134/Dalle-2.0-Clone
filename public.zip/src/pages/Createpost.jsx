import React ,{useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { preview } from '../assets'
import { getRandomPrompt } from '../utils'
import { Formfield,Loader } from '../components'



const Createpost = () => {
    const navigate = useNavigate();
    const [form,setform] =useState({
        name:'',
        prompt:'',
        photo:''
    });
    cont [generatingimg,setgeneratingimg]=useState(flase);
    cont [loading,setloading]=useState(flase); 

  return (
   <div>hello world</div>
   
  )
}

export default Createpost
