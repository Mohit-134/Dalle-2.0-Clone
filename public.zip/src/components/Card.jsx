import React from 'react'

const Card = () => {
  return (
    <div>
      car
    </div>
  )
}

export default Card
